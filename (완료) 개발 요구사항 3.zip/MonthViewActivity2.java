package com.hansung.android.androidproject1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.Calendar; // Calendar 참조 출처 : https://m.blog.naver.com/PostView.naver?isHttpsRedirect=true&blogId=javaking75&logNo=140176424969 

public class MonthViewActivity2 extends AppCompatActivity {

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    static int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
// 캘린더 코드 시작
        Calendar cal = Calendar.getInstance(); //Calendar 객체 얻어오기 ( 시스템의 현재날짜와 시간정보 )
        
        int year = cal.get(Calendar.YEAR); //Calendar 인스턴스에 있는 저장된 필드 값을 가져옴
        int month = cal.get(Calendar.MONTH); //달이 0월부터 시작하므로 +1 
        int day = cal.get(Calendar.DATE); 
        int dayofweek = cal.get(Calendar.DAY_OF_WEEK); // 일요일은 1, 월요일 2......토요일 7
        int lastDay = cal.getActualMaximum(Calendar.DATE); //해당 월의 마지막 일(date)를 반환
        
   // 해당 월의 1일을 구하는 코드
        int copy_day = day;
        int copy_dayofweek = dayofweek;
        
        while(copy_day > 0)
        {
            copy_day -= 7;
        }
        copy_day += 7; 
        
        while(copy_day != 1)
        {
            copy_day -= 1;
            copy_dayofweek -= 1;
            if (copy_dayofweek == 0)
            {
                copy_dayofweek = 7;
            }
        }
   // 코드 끝
        
        String[] days = new String[42];
        
        for (int i = 0; i < copy_dayofweek-1; i++)
        {
            days[i] = " ";
        }
        
        for (int i = copy_dayofweek-1; i < 42; i++)
        {
                if (i-copy_dayofweek>lastDay-2)
                {
                    days[i] = " ";
                }
                else
                {
                    days[i] = Integer.toString(i-copy_dayofweek+2);
                }
        }

        TextView monthText = findViewById(R.id.monthText); //year, month        
        Intent intent = getIntent();
        count = intent.getIntExtra("dataFromFirstActivity", 0);
        if (count != 0)
        {
            month += count;
            if (month > 11)
            {
                month -= 12;
                year += 1;
            }
            if (month < 0)
            {
                month += 12;
                year -= 1;
            }            
            String x = year+"년 "+(month+1)+"월";
            monthText.setText(x);
        }
        else
        {
            String x = year+"년 "+(month+1)+"월";
            monthText.setText(x);
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, days);
        
        GridView gridview = (GridView) findViewById(R.id.monthView);
        
        gridview.setAdapter(adapter);

// 캘린더 코드 끝
    }
    
    public void doAction1(View v)
    {
          Intent intent = new Intent(getApplicationContext(), MonthViewActivity.class);
          count++;
          intent.putExtra("dataFromFirstActivity", count);
          startActivity(intent);
          finish();
    }
    
    public void doAction2(View v)
    {
          Intent intent = new Intent(getApplicationContext(), MonthViewActivity2.class);
          count--;
          intent.putExtra("dataFromFirstActivity", count);          
          startActivity(intent);
          finish();     
    }    
}